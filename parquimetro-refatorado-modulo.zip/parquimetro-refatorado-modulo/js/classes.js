export class Parquimetro {
    constructor(tabela) { this.tabela = tabela; }

    calcular(valor) {
        const opcao = this.tabela.find((item) => valor >= item.preco);
        if (!opcao) return { valido: false, mensagem: "Valor insuficiente. Insira pelo menos R$ 1,00." };
        const troco = Number((valor - opcao.preco).toFixed(2));
        return { valido: true, tempo: opcao.tempo, troco };
    }
}
