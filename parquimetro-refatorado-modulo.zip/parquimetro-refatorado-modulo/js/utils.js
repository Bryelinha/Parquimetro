export const tabelaPrecos = [
    { tempo: 120, preco: 3.00 },
    { tempo: 60, preco: 1.75 },
    { tempo: 30, preco: 1.00 }
];

export const formatarMoeda = (valor) => valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const converterValor = (valor) => Number.parseFloat(valor);
export const validarValor = (valor) => Number.isFinite(valor) && valor >= 1;
export const formatarTabela = (tabela) => tabela.map((item) => ({ ...item, descricao: `${item.tempo} minutos - ${formatarMoeda(item.preco)}` }));
export const encontrarOpcao = (tabela, valor) => tabela.find((item) => valor >= item.preco);
export const somarPrecos = (tabela) => tabela.reduce((total, item) => total + item.preco, 0);
