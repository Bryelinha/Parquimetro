import { Parquimetro } from "./classes.js";
import { tabelaPrecos, formatarMoeda, converterValor, validarValor, formatarTabela, encontrarOpcao, somarPrecos } from "./utils.js";

const form = document.getElementById("formParquimetro");
const valorInput = document.getElementById("valor");
const resultado = document.getElementById("resultado");
const parquimetro = new Parquimetro(tabelaPrecos);

function exibirResultado(dados) {
    if (!dados.valido) {
        resultado.innerHTML = `<p class="erro">${dados.mensagem}</p>`;
        return;
    }
    resultado.innerHTML = `<p><strong>Tempo:</strong> ${dados.tempo} minutos</p><p><strong>Troco:</strong> ${formatarMoeda(dados.troco)}</p>`;
}

form.addEventListener("submit", (event) => {
    event.preventDefault();
    const valor = converterValor(valorInput.value);
    if (!validarValor(valor)) {
        exibirResultado({ valido: false, mensagem: "Digite um valor válido de no mínimo R$ 1,00." });
        return;
    }
    exibirResultado(parquimetro.calcular(valor));
});

console.log("Tabela formatada:", formatarTabela(tabelaPrecos));
console.log("Opção para R$ 2,00:", encontrarOpcao(tabelaPrecos, 2));
console.log("Soma dos preços:", somarPrecos(tabelaPrecos));
console.log("Cálculo para R$ 5,00:", parquimetro.calcular(5));
